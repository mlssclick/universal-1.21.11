package software.bernie.geckolib.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import software.bernie.geckolib.GeckoLibConstants;

import java.util.Optional;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.network.HashedPatchMap;
import net.minecraft.network.HashedStack;

/**
 * Injection into the HashedStack handling to allow for bypassing GeckoLib ItemStack ID parity
 */
@Mixin(HashedStack.ActualItem.class)
public class HashedStackMixin {
    /**
     * In {@code ItemStackMixin#geckolib$skipGeckolibIdOnCompare}, we tell Minecraft to ignore the contents of GeckoLib
     * stack ids for the purposes of ItemStack parity.
     * <p>
     * We temporarily reinstate it here so that the game syncs changes to this specific component
     */
    @WrapOperation(method = "matches", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/HashedPatchMap;matches(Lnet/minecraft/core/component/DataComponentPatch;Lnet/minecraft/network/HashedPatchMap$HashGenerator;)Z"))
    public boolean geckolib$allowLazyStackIdParity(HashedPatchMap patchMap, DataComponentPatch componentPatch, HashedPatchMap.HashGenerator hasher, Operation<Boolean> original) {
        if (!original.call(patchMap, componentPatch, hasher))
            return false;

        DataComponentType<Long> componentType = GeckoLibConstants.STACK_ANIMATABLE_ID_COMPONENT.get();
        int remoteStackHashedId = patchMap.addedComponents().getOrDefault(componentType, Integer.MIN_VALUE);
        int localStackHashedId = Optional.ofNullable(componentPatch.get(componentType))
                .map(optional ->
                             optional.map(value -> hasher.apply(new TypedDataComponent<>(componentType, (long)value)))
                                     .orElse(Integer.MIN_VALUE))
                .orElse(Integer.MIN_VALUE);

        return remoteStackHashedId == localStackHashedId;
    }
}
